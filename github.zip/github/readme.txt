=== GitHub Code Viewer ===

Contributors: mattc78
Tags: github, snippet, code
Requires at least: 2.6
Tested up to: 2.6
Stable tag: trunk

GitHub Code Viewer automatically pulls a file from and displays it in a blog post.

== Description ==

GitHub Code Viewer automatically pulls a file from and displays it in a blog post.

== Installation ==

1. Upload `github.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. To display a file in your blog take the link from GitHub and change "http" to "httpc".
